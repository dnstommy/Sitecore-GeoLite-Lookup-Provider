This module installs the following files:
1. The SharedSource.GeoLite assembly
2. The z.SharedSource.GeoLite configuration file 
3. The GeoLiteCity.dat database file.

For additional information on the SharedSource.GeoLite module, 
please see the blog post at 
http://www.craigtaylor.us/2013/07/creating-geoip-lookup-provider-for.html